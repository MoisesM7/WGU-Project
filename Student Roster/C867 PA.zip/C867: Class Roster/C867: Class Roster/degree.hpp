//
//  degree.hpp
//  C867: Class Roster
//
//  Created by Moises Mercado on 12/2/23.
//

#ifndef degree_hpp
#define degree_hpp
#include <string>

//Enumerated data type DegreeProgram
enum DegreeProgram {SECURITY, NETWORK, SOFTWARE };



#endif






